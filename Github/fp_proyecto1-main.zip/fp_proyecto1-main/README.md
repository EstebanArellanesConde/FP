# fp_proyecto1

Este proyecto contiene el código inicial para convertir un número en base 10 a binario y de binario a base 10
