#ifndef FUNCIONES_H
#define FUNCIONES_H

int conv_binario_decimal(char binario[]);
void conv_decimal_binario(int num, char *binario);

#endif